class ApiConnect {
  static const hostConnect =
      "https://2721-103-109-209-244.ap.ngrok.io//EDIFARM";
  static const connectApi = "$hostConnect/api";

  //login
  static const signin = "$connectApi/login.php";
  //profil
  static const userInfo = "$connectApi/red_data.php";
}
